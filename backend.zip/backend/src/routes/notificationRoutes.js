import express from 'express';
import { authMiddleware } from '../middleware/authMiddleware.js';
import { sendSuccess, sendError } from '../utils/response.js';
import Notification from '../models/Notification.js';

const router = express.Router();

// Stubs for notifications
// List notifications for current user
router.get('/notifications', authMiddleware, async (req, res) => {
  try {
    const notifications = await Notification.find({ targetUser: req.user._id })
      .sort({ createdAt: -1 })
      .populate('actor', 'username profilePic role')
      .populate('post', '_id caption')
      .lean();
    return sendSuccess(res, { data: { notifications } });
  } catch (err) {
    return sendError(res, { message: 'Failed to load notifications' });
  }
});

// Mark one notification as read
router.patch('/notifications/:id/read', authMiddleware, async (req, res) => {
  try {
    await Notification.updateOne({ _id: req.params.id, targetUser: req.user._id }, { read: true });
    return sendSuccess(res, { data: { read: true } });
  } catch (err) {
    return sendError(res, { message: 'Failed to mark read' });
  }
});

// Mark all as read
router.patch('/notifications/read-all', authMiddleware, async (req, res) => {
  try {
    await Notification.updateMany({ targetUser: req.user._id }, { read: true });
    return sendSuccess(res, { data: { read: true } });
  } catch (err) {
    return sendError(res, { message: 'Failed to mark all read' });
  }
});

export default router;
