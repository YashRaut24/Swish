import express from 'express';
import httpStatus from 'http-status';
import Chat from '../models/Chat.js';
import { authMiddleware } from '../middleware/authMiddleware.js';
import { sendError, sendSuccess } from '../utils/response.js';

const router = express.Router();

// GET /api/chats
router.get('/chats', authMiddleware, async (req, res) => {
  try {
    const chats = await Chat.find({ participants: req.user._id })
      .populate('participants', 'username profilePic role')
      .lean();
    return sendSuccess(res, { data: { chats } });
  } catch (err) {
    console.error('Get chats error:', err);
    return sendError(res, { status: httpStatus.INTERNAL_SERVER_ERROR, message: 'Failed to fetch chats' });
  }
});

// POST /api/chats/send
router.post('/chats/send', authMiddleware, async (req, res) => {
  try {
    const { recipientId, message } = req.body;
    if (!recipientId || !message) {
      return sendError(res, { status: httpStatus.BAD_REQUEST, message: 'recipientId and message required' });
    }

    // Find existing chat
    let chat = await Chat.findOne({
      participants: { $all: [req.user._id, recipientId], $size: 2 },
      isGroup: false,
    });

    if (!chat) {
      chat = await Chat.create({ participants: [req.user._id, recipientId], messages: [] });
    }

    chat.messages.push({ sender: req.user._id, text: message });
    await chat.save();

    const populated = await Chat.findById(chat._id)
      .populate('participants', 'username profilePic role')
      .lean();

    // emit via socket if available
    const io = req.app.get('io');
    if (io) {
      [req.user._id.toString(), recipientId.toString()].forEach((uid) => {
        io.to(uid).emit('chat:message', { chatId: chat._id, message: { sender: req.user._id, text: message, createdAt: new Date() } });
      });
    }

    return sendSuccess(res, { data: { chat: populated } });
  } catch (err) {
    console.error('Send message error:', err);
    return sendError(res, { status: httpStatus.INTERNAL_SERVER_ERROR, message: 'Failed to send message' });
  }
});

export default router;
