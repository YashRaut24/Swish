import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createServer } from 'node:http';
import express from 'express';
import cors from 'cors';
import morgan from 'morgan';
import dotenv from 'dotenv';
import { Server } from 'socket.io';
import connectDB from './config/db.js';
import authRoutes from './routes/authRoutes.js';
import stubRoutes from './routes/stubRoutes.js';
import { sendError } from './utils/response.js';
import postRoutes from './routes/postRoutes.js';
import uploadRoutes from './routes/uploadRoutes.js';
import userRoutes from './routes/userRoutes.js';
import chatRoutes from './routes/chatRoutes.js';
import notificationRoutes from './routes/notificationRoutes.js';
import shareRoutes from './routes/shareRoutes.js';
import communityRoutes from './routes/communityRoutes.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const envPath = path.join(__dirname, '../.env');
dotenv.config({ path: envPath });

console.log('Environment loaded from:', envPath);
console.log('Cloudinary Config Check:');
console.log('  CLOUDINARY_CLOUD_NAME:', process.env.CLOUDINARY_CLOUD_NAME ? '✓' : '✗');
console.log('  CLOUDINARY_API_KEY:', process.env.CLOUDINARY_API_KEY ? '✓' : '✗');
console.log('  CLOUDINARY_API_SECRET:', process.env.CLOUDINARY_API_SECRET ? '✓' : '✗');

const app = express();
const httpServer = createServer(app);

const defaultOrigins = ['http://localhost:5173', 'http://localhost:3000'];
const corsOrigins = process.env.CLIENT_ORIGIN
  ? process.env.CLIENT_ORIGIN.split(',').map((origin) => origin.trim())
  : defaultOrigins;

const corsOptions = {
  origin: corsOrigins,
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
  optionsSuccessStatus: 200,
};

app.use(cors(corsOptions));

// Fallback header setter to ensure CORS headers present on all responses
app.use((req, res, next) => {
  const origin = req.headers.origin;
  if (origin && corsOrigins.includes(origin)) {
    res.header('Access-Control-Allow-Origin', origin);
  }
  res.header('Access-Control-Allow-Credentials', 'true');
  res.header('Access-Control-Allow-Methods', 'GET,POST,PUT,PATCH,DELETE,OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  next();
});

// Ensure Express responds to preflight requests for all routes
app.options('*', cors(corsOptions));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(morgan('dev'));

app.use('/api/auth', authRoutes);
app.use('/api', uploadRoutes);
app.use('/api', postRoutes);
app.use('/api', userRoutes);
app.use('/api', chatRoutes);
app.use('/api', notificationRoutes);
app.use('/api', shareRoutes);
app.use('/api', communityRoutes);
// Temporary stub routes to prevent 404s for missing resources
app.use('/api', stubRoutes);

app.use((req, res) => sendError(res, { status: 404, message: 'Route not found' }));

app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  return sendError(res, { status: err.status || 500, message: err.message || 'Internal server error' });
});

const io = new Server(httpServer, {
  cors: {
    origin: corsOrigins,
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization'],
  },
});

io.on('connection', (socket) => {
  socket.on('disconnect', () => {});
});

app.set('io', io);

const PORT = process.env.PORT || 5000;

const start = async () => {
  try {
    await connectDB();
    console.log('✅ MongoDB Connected');

    // 1. Setup error listener to catch "Port Busy" errors
    httpServer.on('error', (err) => {
      if (err.code === 'EADDRINUSE') {
        console.warn(`⚠️  Port ${PORT} is busy. Switching to a random available port...`);
        
        // 2. Retry with Port 0 (System assigns random port)
        const randomServer = httpServer.listen(0, () => {
          const newPort = randomServer.address().port;
          console.log(`\n🚀 Server is running!`);
          console.log(`👉 URL: http://localhost:${newPort}`);
        });
      } else {
        console.error('❌ Server error:', err);
        process.exit(1);
      }
    });

    // 3. Attempt to listen on the preferred port first
    httpServer.listen(PORT, () => {
      console.log(`\n🚀 Server is running!`);
      console.log(`👉 URL: http://localhost:${PORT}`);
    });

  } catch (err) {
    console.error('❌ Server startup failed:', err.message);
    process.exit(1);
  }
};

start();