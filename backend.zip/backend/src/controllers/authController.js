import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import httpStatus from 'http-status';
import User from '../models/User.js';
import { sendError, sendSuccess } from '../utils/response.js';

const SALT_ROUNDS = 10;

const createToken = (user) => {
  if (!process.env.JWT_SECRET) {
    throw new Error('JWT_SECRET is not defined in environment variables');
  }
  return jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '7d' });
};

const populateUser = async (userId) => {
  try {
    const user = await User.findById(userId)
      .select('-password')
      .populate('followers', 'username profilePic role')
      .populate('following', 'username profilePic role')
      .populate('communities', 'name')
      .lean();
    return user;
  } catch (err) {
    console.error('Populate user error:', err);
    // Fallback: return user without populates
    const user = await User.findById(userId).select('-password').lean();
    return user;
  }
};

export const register = async (req, res) => {
  try {
    const { username, email, password, role } = req.body;

    console.log('Register attempt:', { username, email, role });

    if (!username || !email || !password) {
      return sendError(res, { status: httpStatus.BAD_REQUEST, message: 'Username, email, and password are required' });
    }

    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return sendError(res, { status: httpStatus.CONFLICT, message: 'Email is already registered' });
    }

    const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);

    const user = await User.create({ username, email, password: hashedPassword, role });
    const token = createToken(user);
    const sanitizedUser = await populateUser(user._id);
    const userObj = sanitizedUser && sanitizedUser.toObject ? sanitizedUser.toObject() : sanitizedUser;
    if (userObj) userObj.name = userObj.name || userObj.username;

    return sendSuccess(res, {
      status: httpStatus.CREATED,
      message: 'User registered successfully',
      data: { user: userObj || sanitizedUser, token },
    });
  } catch (err) {
    console.error('Register error:', err);
    return sendError(res, { status: httpStatus.INTERNAL_SERVER_ERROR, message: err.message || 'Registration failed' });
  }
};

export const login = async (req, res) => {
  try {
    const { email, password } = req.body;

    console.log('Login attempt:', { email });

    if (!email || !password) {
      return sendError(res, { status: httpStatus.BAD_REQUEST, message: 'Email and password are required' });
    }

    const user = await User.findOne({ email }).select('+password');
    if (!user) {
      return sendError(res, { status: httpStatus.UNAUTHORIZED, message: 'Invalid credentials' });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return sendError(res, { status: httpStatus.UNAUTHORIZED, message: 'Invalid credentials' });
    }

    const token = createToken(user);
    const sanitizedUser = await populateUser(user._id);
    const userObj = sanitizedUser && sanitizedUser.toObject ? sanitizedUser.toObject() : sanitizedUser;
    if (userObj) userObj.name = userObj.name || userObj.username;

    return sendSuccess(res, {
      status: httpStatus.OK,
      message: 'Login successful',
      data: { user: userObj || sanitizedUser, token },
    });
  } catch (err) {
    console.error('Login error:', err);
    return sendError(res, { status: httpStatus.INTERNAL_SERVER_ERROR, message: err.message || 'Login failed' });
  }
};
